package back.enemies;

public interface AutoMovable { // a marker interface, these move automatically
}
