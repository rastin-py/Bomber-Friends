package back.walls;

public interface Immovable { // a marker interface, you can't move these
}
